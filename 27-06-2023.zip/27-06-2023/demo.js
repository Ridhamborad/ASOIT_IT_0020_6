let x = 20,
    y = 30;
var z = x + y;
var w = x - y;
var u = x * y;
console.log("sum of x + y =" + z);
document.write("<br>sum of x + y =" + z);

console.log("sum of x + y =" + w);
document.write("<br>sum of x + y =" + w);

console.log("sum of x + y =" + u);
document.write("<br>sum of x + y =" + u);